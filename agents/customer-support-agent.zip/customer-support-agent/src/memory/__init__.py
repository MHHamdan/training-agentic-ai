"""Memory management modules"""
